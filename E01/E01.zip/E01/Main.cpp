#include "Main.h"

int main() {
	std::cout << "Hello World!\n";

	std::cout << "Press enter to finish";
	getchar();
	return 0;
}